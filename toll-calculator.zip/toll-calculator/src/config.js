export const TOLL_GURU_API_URL = "https://apis.tollguru.com";
export const API_KEY = "6bdmGgqrm847PLNh44H8Hqh6dJT9pH7G";