import React, { Fragment, useEffect, useState } from "react";
import { TileLayer, useMap, Polyline, MapContainer, Popup, Marker, useMapEvents } from 'react-leaflet'
import 'leaflet/dist/leaflet.css';
import { marker } from "leaflet";
import MapMarker from "./MapMarker";

const Map = ({polylinePositions}) => {
  // const polylinePositions = [
  //     [51.505, -0.09],
  //     [51.51, -0.1],
  //     [51.51, -0.12]
  //   ];
  
  const mapSettings = {
    center: [20.593, 78.962],
    zoom: 6
  };
  
  return (
  <Fragment>
    <MapContainer center={mapSettings.center} zoom={mapSettings.zoom} style={{ height: '400px', width: '100%' }}>
    <TileLayer
      url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    />
    <Polyline positions={polylinePositions} color="purple" />
    <MapMarker/>
  </MapContainer>
    
  </Fragment>
  );
}

export default Map;