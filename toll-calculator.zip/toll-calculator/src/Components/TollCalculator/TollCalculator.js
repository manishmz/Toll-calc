import React, { Fragment } from "react";
import Map from "../Map/Map";
import TollCalculatorForm from './Form/TollCalculatorForm';
import { decode, encode } from "@googlemaps/polyline-codec";
import { TOLL_GURU_API_URL, API_KEY } from "./../../config";
import { useSelector } from "react-redux";

const TollCalculator = () => {
    const fromAddress = useSelector(state=> state.fromAddress);
    const toAddress = useSelector(state=> state.toAddress);
  
    const getPolyLineFromOriginAndDest = async () => {
        const data = {
            from: fromAddress,
            to: toAddress,
            waypoints: [],
            vehicle: {type: "2AxlesAuto"}
          };
          console.log(data);
          const response = await fetch(`${TOLL_GURU_API_URL}/toll/v2/origin-destination-waypoints`, {
            method: "POST",
            headers: {
              "x-api-key": API_KEY,
              "Content-Type": "application/json",
              "Accept": "application/json"
            },
            body: JSON.stringify(data)
          });
          const result = await response.json();
          console.log(result);
    };
    
    const onSubmit = async event => {
        console.log("on submit");
        getPolyLineFromOriginAndDest();
        event.preventDefault();
    }

    return <>
        <TollCalculatorForm onSubmit={onSubmit}></TollCalculatorForm>
        <Map polylinePositions={decode("", 5)}></Map>
    </>;
}

export default TollCalculator;