import { TextField, MenuItem, Button } from "@mui/material";
import React, { Fragment } from "react";
import { useSelector } from "react-redux";

const TollCalculatorForm = ({onSubmit}) => {
    const defaultVehicleValue = "2AxlesAuto";
    const vehicleTypes = [
        {label: "Car / Jeep / Van / SUV", value: "2AxlesAuto"},
        {label: "Bike", value: "2AxlesMotorcycle"}
    ];
    const fromAddress = useSelector(state=> state.fromAddress);
    const toAddress = useSelector(state=> state.toAddress);
    
    return <Fragment>
      <form onSubmit={onSubmit}>
        <TextField id="fromAddress" label="From Address" helperText="To select an address long press on the map" /> <br />
        <TextField id="toAddress" label="To Address" helperText="To select an address long press on the map" /> <br />
        <TextField
          id="outlined-select-currency"
          select
          label="Select Your Vehicle"
          defaultValue={defaultVehicleValue}
          helperText="Please select your currency"
        >
          {vehicleTypes.map((option) => (
            <MenuItem key={option.value} value={option.value}>
              {option.label}
            </MenuItem>
          ))}
        </TextField><br />
        <Button variant="contained" type="submit">Submit</Button>
      </form>
    </Fragment>
}

export default TollCalculatorForm;