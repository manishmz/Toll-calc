import logo from './logo.svg';
import './App.css';
import TollCalculator from './Components/TollCalculator/TollCalculator';

function App() {
  return (
    <div className="App">
        <TollCalculator></TollCalculator>
    </div>
  );
}

export default App;