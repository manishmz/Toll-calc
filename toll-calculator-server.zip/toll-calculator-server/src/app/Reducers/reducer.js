const intialState = {fromAddress: {}, toAddress: {}, polyline: ""};
const reducer = (state = intialState, action) => {
    let newState = {...state};
    if(action.type == "FROM_ADDRESS") {
        newState = {...state, fromAddress: action.val};
        console.log(newState);
    }

    if(action.type == "TO_ADDRESS") {
        newState = {...state, toAddress: action.val};
        console.log(newState);
    }

    if(action.type == "POLYLINE") {
        newState = {...state, polyline: action.val};
    }

    return newState;
}

export default reducer;