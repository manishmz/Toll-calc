import { NextResponse } from "next/server";

const TOLL_GURU_API_URL = "https://apis.tollguru.com";

export async function POST(req, res) {
    try {
        const body = await req.json();
    const response = await fetch(`${TOLL_GURU_API_URL}/toll/v2/origin-destination-waypoints`, {
        method: "POST",
        headers: {
          "x-api-key": "6bdmGgqrm847PLNh44H8Hqh6dJT9pH7G",
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: JSON.stringify(body)
    });
    const result = await response.json();
    console.log(result);
    return NextResponse.json(result);
      } catch (error) {
        // TypeError: Failed to fetch
        return NextResponse.json(error);
      }
    
}

// export async function POST(req, res) {
//     const body = await req.json();
//     return NextResponse.json(body);
// }