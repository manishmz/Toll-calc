"use client";

import React, { useMemo, useRef, useState } from "react";
import { Marker, useMapEvents } from "react-leaflet";
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { useDispatch } from "react-redux";

import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

let DefaultIcon = L.icon({
    iconUrl: icon,
    shadowUrl: iconShadow
});

L.Marker.prototype.options.icon = DefaultIcon;

const MapMarker = () => {
    const [positions, setPositions] = useState([]);
    const dispatch = useDispatch();
    const addPosition = (latlng) => {
        if(positions.length == 0 || positions.length == 2) {
            setPositions([latlng]);
            dispatch({type: 'FROM_ADDRESS', val: latlng});
        }
        else {
            setPositions(positions.concat(latlng));
            dispatch({type: 'TO_ADDRESS', val: latlng})
        }
    }

    const map = useMapEvents({
        click(e) {
          console.log("click map");
          addPosition(e.latlng);
          
        }
      });

    return <>
    {positions.map((position, i) => <Marker key={i} position={position}
      ></Marker>)}
    </>;
}

export default MapMarker;