"use client";

import React, { Fragment } from "react";
import Map from "../Map/Map";
import TollCalculatorForm from './Form/TollCalculatorForm';
import { decode, encode } from "@googlemaps/polyline-codec";
import { useSelector } from "react-redux";
import useSWR from 'swr';

const TOLL_GURU_API_URL = "https://apis.tollguru.com";

const TollCalculator = () => {
    const fromAddress = useSelector(state=> state.fromAddress);
    const toAddress = useSelector(state=> state.toAddress);
  
    // const getPolyLineFromOriginAndDest = async () => {
    //     const bodyRequest = {
    //         from: fromAddress,
    //         to: toAddress,
    //         waypoints: [],
    //         vehicle: {type: "2AxlesAuto"}
    //       };
    //       console.log(data);
          
    //       const { response, error } = useSWR(['/api/toll-guru/PostOriginDestinationWaypoints', bodyRequest], async (data) => {
    //         const response = await fetch(`${TOLL_GURU_API_URL}/toll/v2/origin-destination-waypoints`, {
    //             method: "POST",
    //             headers: {
    //               "x-api-key": process.env.TOLL_GURU_API_KEY,
    //               "Content-Type": "application/json",
    //               "Accept": "application/json"
    //             },
    //             body: JSON.stringify(data)
    //           });
    //           const result = await response.json();
    //           console.log(result);
    //     });

    //       if (response) {
    //         console.log(response);
    //       }
    // };
    
    const onSubmit = async event => {
        console.log("on submit");
       // getPolyLineFromOriginAndDest();
        event.preventDefault();
    }

    return <>
        <TollCalculatorForm onSubmit={onSubmit}></TollCalculatorForm>
        <Map polylinePositions={decode("", 5)}></Map>
    </>;
}

export default TollCalculator;